// +build !go1.12

package zerolog

const contextCallerSkipFrameCount = 3
